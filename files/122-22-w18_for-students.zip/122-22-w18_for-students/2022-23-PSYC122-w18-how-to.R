


############################################################################################################


# In Week 18, we aim to *further* develop skills in working with the linear model

# We do this to learn how to answer research questions like:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written 
# health information?

# These kinds of research questions can be answered using methods like the linear model

# When we do these analyses, we will need to think about how we report the results:  
# -- we usually need to report information about the kind of model we specify;
# -- and we will need to report the nature of the associations estimated in our model;
# -- we usually need to decide, is the association between the outcome and any one
# predictor significant?
# -- does that association reflect a positive or negative relationship between the
# outcome and that predictor?
# -- are the associations we see in sample data relatively strong or weak?

# We will consolidate and extend learning on data visualization:
# -- Using scatterplots to examine the relationships we may observe or predict
# -- Generating predictions given model estimates of slope coefficients



############################################################################################################


# -- We will take things step-by-step --

# -- I will be explicit about when I will:
# -- introduce -- ask you to do something new;
# -- revise -- where you have started to do things and maybe can use some 
# practice to strengthen skills;
# -- consolidate -- where you have had the chance to practice things before;
# -- extend -- where you can do things that will stretch you -- where you might
# need to do some independent research



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("ggeffects")
library("tidyverse")



############################################################################################################
############################################################################################################


# -- In this how-to guide, we use data from a 2020 study of the response of adults from a UK national
# sample to written health information:

# study-one-general-participants.csv



############################################################################################################
## Part 2: Load data #######################################################################################


# -- Task 3 -- Read in the data file we will be using: 
# study-one-general-participants.csv

# -- We use the read_csv() function to read the data file into R
study.one <- read_csv("study-one-general-participants.csv")  


# -- Task 4 -- Inspect the data file
# -- hint: Task 4 -- Use the summary() or head() functions to take a look
head(study.one)
summary(study.one)

# -- head() will give you the top few rows of any dataset you have read into R

# -- summary() will give you either descriptive statistics for variable columns
# classified as numeric or will tell you that columns in the dataset are not numeric



############################################################################################################
## Part 3: Use a linear model to to answer the research questions -- one predictor #########################


# -- revision: practice to strengthen skills --


# -- revision: we start by revising how to use lm() with one predictor --


# -- One of our research questions is:
# 1. What person attributes predict success in understanding?

# -- Task 5 -- Examine the relation between outcome mean accuracy (mean.acc) and 
# health literacy (HLVA)
# -- hint: Task 6 -- We use lm()
model <- lm(mean.acc ~ HLVA, data = study.one)
summary(model)

  
# -- If you look at the model summary you can answer the following questions  

# -- Q.1. -- What is the estimate for the coefficient of the effect of the predictor, HLVA?
# -- A.1. -- 0.02272 

# -- Q.2. -- Is the effect significant?
# -- A.2. -- It is significant, p < .05

# -- Q.3. -- What are the values for t and p for the significance test for the coefficient?
# -- A.3. -- t = 6.158, p = 5.31e-09

# -- Q.4. -- What do you conclude is the answer to the research question, given the 
# linear model results?
# -- A.4. -- The model slope estimate suggests that as HLVA scores increase so also 
# do mean.acc scores

# -- Q.5. -- What is the F-statistic for the regression? Report F, DF and the p-value.
# -- A.5. -- F-statistic: 37.92 on 1 and 167 DF,  p-value: 5.307e-09

# -- Q.6. -- Is the regression significant?
# -- A.6. -- Yes: the regression is significant.

# -- Q.7. -- What is the Adjusted R-squared?
# -- A.7. -- Adjusted R-squared:  0.1802

# -- Q.8. -- Explain in words what this R-squared value indicates?
# -- A.8. -- The R-squared suggests that 18% of outcome variance can be explained 
# by the model


# -- revision: use a linear model to generate predictions --


# -- Task 6 -- We can use the model we have just fitted to plot the model 
# predictions
# -- hint: Task 6 -- We are going to draw a scatterplot and add a line showing 
# the predictions, given the model intercept and effect coefficient estimates

# -- Q.9. -- What is the coefficient estimate for the intercept?
# -- A.9. -- 0.61399

# -- Q.10. -- What is the coefficient estimate for the slope of HLVA?
# -- A.10. -- 0.02272

# -- Use the geom_abline() function to draw the prediction line:
ggplot(data = study.one, aes(x = HLVA, y = mean.acc)) +
  geom_point(alpha = 0.5, size = 2,)   +
  geom_abline(intercept = 0.61399, slope = 0.02272, colour = "red", size = 1.5) +
  theme_bw() +
  labs(x = "Health literacy (HLVA)", y = "mean accuracy") +
  xlim(0, 16) + ylim(0, 1)
  
# -- You can see that all we do is:
# -- add the geom_abline(...) function
# -- and in that geom_abline(...) function, add information about the intercept 
# and the slope

# -- See reference information here for other examples and for more information:  
#   https://ggplot2.tidyverse.org/reference/geom_abline.html      



############################################################################################################
## Part 4: Use a linear model to to answer the research questions -- multiple predictors ###################


# -- encounter: make some new moves --


# -- Task 7 -- Examine the relation between outcome mean accuracy (mean.acc)
# and multiple predictors including:
# health literacy (HLVA); vocabulary (SHIPLEY); and reading strategy (FACTOR3)
# -- hint: Task 8 -- We use lm(), as before, but now specify each variable listed 
# here by variable name
model <- lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3, data = study.one)
summary(model)

# -- Notice that we do the linear model in the steps:

# -- 1 -- model <- lm(...) -- fit the model using lm(...), give the model a name 
# -- here, we call it "model"

# -- 2 -- ...lm(mean.acc ~ HLVA...) 
# -- tell R you want a model of the outcome 'mean.acc' 
# -- predicted (~) by the predictors:
# 'HLVA', 'SHIPLEY', 'FACTOR3'

# -- Note that we use the variable names as they appear in the dataset, and that 
# each predictor variable is separated from the next by a plus sign

# -- 3 -- ...data = study.one) -- tell R that the variables you name 
# in the formula live in the 'study.one' dataset

# -- 4 -- summary(model) -- ask R for a summary of the model you called "model"


# -- Notice: R has a general formula syntax: outcome ~ predictor *or* y ~ x
# -- and uses the same format across a number of different functions
# -- each time, the left of the tilde symbol ~ is some output or outcome
# -- and the right of the tilde ~ is some input or predictor or set of predictors


# -- If you look at the model summary you can answer the following questions  

# -- Q.11. -- What is the estimate for the coefficient of the effect of the predictor, 
# 'HLVA;, in *this* model?
# -- A.11. -- 0.017732 

# -- Q.12. -- Is the effect significant?
# -- A.12. -- It is significant, p < .05

# -- Q.13. -- What are the values for t and p for the significance test for the coefficient?
# -- A.13. -- t = 4.521, p = 1.17e-05

# -- Q.14. -- What do you conclude is the answer to the research question, 
# given the linear model results?
# -- A.14. -- The model slope estimate 0.0274954 suggests that as HLVA scores 
# increase so also do mean.acc scores

# -- Q.15. -- How is the coefficient estimate for the HLVA slope similar or different, 
# comparing this model with multiple predictors to the previous model with one predictor?
# -- A.15. -- It can be seen that the HLVA estimate in the two models is different 
# in that it is a bit smaller in the model with multiple predictors compared to the 
# model with one predictor 
# -- The HLVA estimate is similar in that it remains positive, it is about the 
# same size


# -- Notice that:-

#   -- The estimate of the coefficient of any one predictor can be expected to 
# vary depending on the presence of other predictors.
# -- This is one reason why we need to be transparent about why we choose to use 
# the predictors we include in our model.
# -- The lecture for week 18 discusses this concern in relation to the motivation 
# for good open science practices.

  
# -- Q.16. -- Can you report the estimated effect of SHIPLEY (the measure of vocabulary)
# using the kind of language you are shown in lecture week 18?
# -- A.16. -- The effect of vocabulary knowledge (SHIPLEY) on mean accuracy of 
# understanding is significant (estimate = 0.005, t = 2.296, p < .001)
# indicating that increasing skill is associated with increasing accuracy

# -- Q.17. -- Can you report the model and the model fit statistics?
# -- A.17. -- We fitted a linear model with mean comprehension accuracy as the 
# outcome and health literacy (HLVA),  reading strategy (FACTOR3), and vocabulary 
# (SHIPLEY) as predictors.
# The model is significant overall, with F(3, 165) = 18.087, p< .001, and 
# explains 23% of variance (adjusted R2 = 0.23).



############################################################################################################
## Part 5: Plot predictions from linear models with multiple predictors ####################################


# -- encounter: make some new moves --


# -- Task 8 -- Plot linear model predictions for one of the predictors
# -- hint: Task 9 -- Previously, we used geom_abline(), specifying intercept and 
# slope estimates, to draw model predictions
# -- Here, we use functions that are very helpful when we need to plot model 
# predictions for a predictor, for models where we have multiple predictors, and 
# we have to take into account the influence on outcomes of the other predictors
  

# -- We do this in three steps:
# -- 1 -- We first fit a linear model of the outcome, given our predictors
# -- We save information about the model
# -- 2 -- We use the ggpredict() function from the 'ggeffects' library to take  
# the information about the model and create a set of predictions we can use for plotting
# -- 3 -- We plot the model predictions (marginal effects plots)


# -- These steps proceed as follows:-


# -- 1 -- We first fit a linear model of the outcome, given our predictors
model <- lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3, data = study.one)
# -- 1.1 -- model <- lm(...) -- we fit the model using lm(...), give the model a name 
# -- here, we call it "model"
# -- 1.2 -- ...lm(mean.acc ~ HLVA...) 
# -- tell R you want a model of the outcome 'mean.acc' predicted (~) by
# the predictors 'HLVA', 'SHIPLEY', 'FACTOR3'

# -- Notice: when we use lm() to fit the model, R creates a set of information 
# about the model, including estimates
# -- We give that set of information a name, and we use that name, next, to 
# access the model information

# -- 2 -- We use the ggpredict() function from the 'ggeffects' library to take  
# the information about the model and create a set of predictions we can use for 
# plotting  
dat <- ggpredict(model, "HLVA")

# -- Notice:
# -- 2.1 -- dat <- ggpredict(...) -- We ask R to create a set of predictions, 
# and we give that set of predictions a name 'dat'
# -- 2.2 -- ... ggpredict(model, "HLVA") -- We tell R what model information 
# it should use (from 'model'), and which predictor variable we need predictions for 'HLVA'

# -- 3 -- We plot the model predictions (marginal effects plots)
plot(dat)


# -- Task 9 -- Edit the appearance of the marginal effect (prediction) plot as 
# you can with any ggplot object
p.model <- plot(dat)
p.model +
  geom_point(data = study.one, 
             aes(x = HLVA, y = mean.acc), size = 1.5, alpha = .75, colour = "lightgreen") +
  geom_line(size = 1.5) +
  ylim(0, 1.1) + xlim(0, 16) +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.15)),
    axis.title = element_text(size = rel(1.25)),
    plot.title = element_text(size = rel(1.4))
  ) +
  xlab("Health literacy (HLVA)") + ylab("Mean accuracy") +
  ggtitle("Effect of health literacy on mean comprehension accuracy")

# -- Notice that we do this in stages, as we have done for other kinds of plots:

# -- 1 -- p.model <- plot(dat) -- we create a plot object, which we call 'p.model'

# -- 2 -- p.model + 
# -- we then set up the first line of a series of lines, starting with the name of 
# the plot, 'p.model' and a + to show we are going to add some edits

# -- 3 -- geom_point(data = study.one, aes(x = HLVA, y = mean.acc) ...) 
# -- we first add the raw data points showing the observed HLVA and mean.acc for 
# each person in our sample

# -- 4 -- geom_point(... size = 1.5, alpha = .75, colour = "lightgreen") + 
# -- we modify the appearance of the points, then

# -- 5 -- geom_line(size = 1.5) + 
# -- we add the prediction line, using the predictions created earlier, then

# -- 6 -- ylim(0, 1.1) + xlim(0, 16) + 
# -- we set axis limits to show the full potential range of variation in each variable, then

# -- 7 -- theme_bw() -- we set the theme to black and white, then

# -- 8 -- theme(axis.text = element_text(size = rel(1.15)), 
#               axis.title = element_text(size = rel(1.25)), 
#               plot.title = element_text(size = rel(1.4))
#               )
# -- we modify the relative size of x-axis, y-axis and plot title label font, then

# -- 9 -- xlab("Health literacy (HLVA)") + ylab("Mean accuracy") + 
# -- we edit labels to make them easier to understand, then

# -- 10 -- ggtitle("Effect of health literacy on mean comprehension accuracy") 
# -- we give the plot a title


# -- Task 10 -- Now produce plots that show the predictions for all the predictor 
# variables in the model

# -- 1 -- Adjust axis labels so for each plot we see the correct predictor as the x-axis label
# -- 2 -- In each plot, first plot the original sample observations as points *then* the prediction line
# -- This ensures that the predictions are printed *on top* of the observed data points.



############################################################################################################
## Part 6: Now draw boxplots to examine associations between variables #####################################


# -- consolidate: practice to strengthen skills --


# -- Task 11 -- Create boxplots to examine the association between a continuous numeric outcome variable
# like 'mean.acc' and a categorical variable like 'ETHNICITY'
# -- hint: Task 11 -- Notice here that we use geom_boxplot()
# -- hint: Task 11 -- We can see where variables are not numeric using:
summary(study.one)


# -- The basic boxplot can be produced using code like this:
ggplot(data = study.one, aes(x = ETHNICITY, y = mean.acc)) +
  geom_boxplot() +
  theme_bw() +
  labs(x = "Ethnicity, ONS categories", y = "Mean accuracy of understanding ('mean.acc')") +
  ylim(0, 1.1)

# -- 1 -- ggplot(data = study.one, aes(x = ETHNICITY, y = mean.acc)) +
# -- You define two aesthetic mappings:
# x = ETHNICITY -- the x variable has to be categorical or nominal, a factor like 
# 'ETHNICITY' with different levels
# -- Here, there are different factor levels corresponding to different ethnicity groups
# y = mean.acc -- the y variable has to be numeric, a set of numbers like 'mean.acc' 
# with different values
# -- 2 -- geom_boxplot() +
# -- Information about category (x = ...) and outcome (y = ...) is fed into geom_boxplot() 
# to draw a box to represent the distribution of outcome scores for each group

# -- Notice:
# -- the middle line in each box represents the median outcome (here 'mean.acc') 
# score for each group
# -- the shape of the box represents the distribution or spread of scores, the 
# top of the box represents the 75th percentile
# (what the score is for the people who are at the top 75% of the sample) and 
# the bottom of the box represents the 25th percentile (what the score is for the 
# people at the 25% level of outcomes for the sample)


# -- More information about boxplots can be found here:
# https://ggplot2.tidyverse.org/reference/geom_boxplot.html


# -- Here is an edit of the plot to make it a bit more effective:
ggplot(data = study.one, aes(x = ETHNICITY, y = mean.acc)) +
  geom_jitter(alpha = .5) +
  geom_boxplot(outlier.shape = NA, colour = "red", alpha = .1) +
  theme_bw() +
  labs(x = "Ethnicity, ONS categories", y = "Mean accuracy of understanding ('mean.acc')") +
  ylim(0, 1.1)

# -- The plot shows:
# -- boxplots to indicate the average (median) and spread (percentiles) in 
# 'mean.acc' scores for each group;
# -- plus, with points, individual 'mean.acc' scores for the people in each group


# -- Now you can use the plots to answer questions like the following


# -- Q.18. -- What do you notice about the distribution of scores in different groups?
# -- A.18. -- The average accuracy of understanding appears to be similar between groups

# -- Q.19. -- Does anything in the plots give you reason to question the nature of 
# the participant sample?
# -- A.19. -- This is a leading question -- there is plenty in the plots to cause concern:
# -- The scatter of points shows that we have many more "White" participants in the 
# sample than participants from other ethnicities
# -- Because we have very few people in the study from BAME groups, we might be 
# concerned about whether the results from our models are representative of what 
# you would see in these groups, or whether the results are representative of the 
# wider population in general

# -- Q.20. -- Can you use the ggplot() reference information -- see the webpage link -- to see how
# and why I made the code edits I did?
# -- A.20. -- You can see example code for each edit in the webpage  

# -- Q.21. -- Do you understand what geom_jitter() is doing? -- and why I would use it?  
# -- A.21. -- What the function does, and why I would use it can be found in the reference 
# information webpage:
# https://ggplot2.tidyverse.org/reference/geom_jitter.html



############################################################################################################


# -- Notice that drawing plots which show *both* summaries (like boxplots) and raw data (scores as points)
# -- Is another common professional visualization technique
# -- It is effective because these kinds of plots help you to see the pattern or trend *and* 
# the nature of the underlying sample  



############################################################################################################
## Part 7: Estimate the effects of factors as well as numeric variables ####################################


# -- consolidate: build your skills --


# -- We have not yet included any categorical or nominal variables as predictors
# but we can, and should: lm() can cope with any kind of variable as a predictor


# -- Task 12 -- Fit a linear model including both numeric variables and categorical 
# variables as predictors
# -- hint: Task 12 -- We can inspect the data to check what variables are
# categorical or nominal variables -- factors -- using summary()
summary(study.one)

# -- R shows categorical variables in the summary as having Class: character


# -- Q.22. -- Can you report the estimated effect of ETHNICITY (the 
# coding of participant self-reported ethnicity group)?
# -- hint: Q.22 -- Include the factor ETHNICITY as a predictor
model <- lm(mean.acc ~ HLVA + SHIPLEY + FACTOR3 + ETHNICITY, 
            data = study.one)
# -- hint: Q.22. -- You will need to get a summary of the model
summary(model)
# -- A.22. -- The effect of ethnicity (ETHNICITY) on mean accuracy of 
# understanding is not significant

# -- Q.23. -- Can you report the model and the model fit statistics?
# -- A.23. -- We fitted a linear model with mean comprehension accuracy as the 
# outcome and health literacy (HLVA),  vocabulary (SHIPLEY), reading strategy (FACTOR3),
# and ethnicity (ETHNICITY) as predictors.
# The model is significant overall, with F(7, 161) = 7.72, p< .001, and 
# explains 22% of variance (adjusted R2 = 0.22).

# -- Q.24. -- What changes, when you compare the models with versus without ETHNICITY?
# -- A.125. -- If you compare the summaries, for the last two models, you can see that
# the proportion of variance explained, R-sq, decreases slightly to 22%
# (Adjusted R-squared = 0.2188), suggesting that adding ETHNICITY as a predictor does
# *not* help to predict response accuracy in tests of comprehension of health advice.

  
# -- R handles factors, by default, by picking one level (here, 'Asian') as the reference level
# (or baseline) and comparing outcomes to that baseline, for each other factor level
# (here, 'Other')
# -- Thus, in this model, the effect of 'ETHNICITY' is estimated as the difference
# in 'mean.acc' outcome for 'Asian' compared to participants coded as
# 'Black, Mixed, Other, White'

# -- There are different ways to code factors for analysis
# -- You will learn about these in second year classes


# -- Task 13 -- Fit a linear model including both numeric variables and categorical 
# variables as predictors, and then plot the predicted effect of the factor
# -- hint: Task 12 -- We first fit the model, including ETHNICITY
# then use the ggpredict() function to get the predictions

dat <- ggpredict(model, "ETHNICITY")
plot(dat)

# -- Q.25. -- Compare the model summary and the prediction plot: what do they
# show you about the effect of ETHNICITY?
# -- A.25. -- If you compare the summary and the plot you can see that:
# -- there are some differences in accuracy between people coded as belonging to
# different ethnic groups;
# -- but these differences are very small and are not significant.
# -- Notice that the points in the plot represent model predictions of the average
# 'mean.acc' accuracy of response for each group. The vertical lines on the point
# represent uncertainty about those estimates and that uncertainty can be seen to
# be substantial.



############################################################################################################

