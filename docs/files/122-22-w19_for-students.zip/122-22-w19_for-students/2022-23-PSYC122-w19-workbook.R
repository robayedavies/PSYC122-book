


############################################################################################################


# In Week 19, we aim to *further* develop skills in working with the linear model

# We focus on the health comprehension project research questions:

# 1. What person attributes predict success in understanding?
# 2. Can people accurately evaluate whether they correctly understand written 
# health information?


# In Week 19, we use data contributed by 2022-23 PSYC122 students to figure out
# our answers to these questions

# We compare the PSYC122 results to the results from analyses of data from a previous 
# similar study to assess the robustness of our results



############################################################################################################
## Part 1: Set-up ##########################################################################################


# -- Task 1 -- Run this code to empty the R environment
rm(list=ls())                            


# -- Task 2 -- Run this code to load relevant libraries
library("ggeffects")
library("patchwork")
library("tidyverse")



############################################################################################################
############################################################################################################


# -- In this workbook, we use data from two studies of the response to written health information:

# -- 1 -- a study we conducted on the response of adults from a UK national participant sample
# study-two-general-participants.csv

# -- 2 -- the 2022-23 PSYC122 study in which we recorded the responses of PSYC122 students
# 2022-23_PSYC122-subjects.csv

# -- Notice that study-two and PSYC122 participants were given similar sets of health information texts
# to read and respond to



############################################################################################################
## Part 2: Load data #######################################################################################


# -- Task 3 -- Read in the data files we will be using: 
# study-two-general-participants.csv
# 2022-23_PSYC122-subjects.csv

# -- We use the read_csv() function to read the data files into R
study.two <- read_csv("study-two-general-participants.csv")  
study.122 <- read_csv("2022-23_PSYC122-subjects.csv")  


# -- Task 4 -- Inspect the data files
# -- hint: Task 4 -- Use the summary() or head() functions to take a look

# -- enter and run your code here --



############################################################################################################
## Part 3: Compare data ####################################################################################


# -- revision: make sure you are confident about doing these things --


# -- Task 5 --  Compare the data distributions from the two different studies


# -- Q.1. -- What is the mean of the mean.acc and SHIPLEY variables in the two
# different studies?

# -- enter your answer here --


# -- Q.2. -- Draw histograms of both mean.acc and mean.self for both studies

# -- enter and run your code here --


# -- introduce: make some new moves --


# -- Task 6 --  Create grids of plots to make the comparison easier to do
# -- hint: Task 6 -- What we are going to do is to create two histograms and then
# present them side by side to allow easy comparison of variable distributions
# -- hint: Task 6 -- We need to make two small changes to the plotting code

# -- Here's an example: run these line of code and see the result in the Plots window in R-Studio

# -- Create plot objects but do not show them:
plot.two <- ggplot(data = study.two, aes(x = mean.acc)) + 
  geom_histogram(binwidth = .1) +
  theme_bw() +
  labs(x = "Mean accuracy (mean.acc)", y = "frequency count", title = "Study Two") +
  xlim(0, 1)

plot.122 <- ggplot(data = study.122, aes(x = mean.acc)) + 
  geom_histogram(binwidth = .1) +
  theme_bw() +
  labs(x = "Mean accuracy (mean.acc)", y = "frequency count", title = "Study PSYC122") +
  xlim(0, 1)

# Now show the plots, side-by-side
plot.two + plot.122

# The coding steps are explained in detail in:
# 2022-23-PSYC122-w19-how-to.R


# -- warning: until you get to step 10, nothing will appear in the plot window


# -- Task 7 --  Create grids of plots to make the comparison easier to do
# -- Try this out for yourself, focusing now on the distribution of SHIPLEY scores in the
# two studies

# -- Create plot objects but do not show them:

# -- enter and run your code here --


# Now show the plots, side-by-side

# -- enter and run your code here --


# -- Notice that you can build complex plots using a step-by-step approach like this


# -- Q.3. -- Now use the plots you have drawn to do some data analysis work: 
# how do the SHIPLEY distributions compare, when you compare the SHIPLEY scores of 
# study.two versus the SHIPLEY scores of study.122?

# -- enter your answer here --


# -- Q.4. -- Is the visual impression you get from comparing the distributions 
# consistent with the statistics you see in the summary?

# -- enter your answer here --



############################################################################################################
## Part 4: Now use scatterplots and correlation to examine associations between variables ##################


# -- revision: make sure you are confident about doing these things --


# -- Task 8 -- Draw scatterplots to compare the potential association between mean.acc
# and mean.self in both study.two and study.122 datasets
# -- hint: Task 8 -- The plotting steps are explained in some detail in:
# 2022-23-PSYC122-w17-how-to.R
# -- and you can see example code in:
# 2022-23-PSYC122-w19-how-to.R

# -- enter and run your code here --


# -- Task 9 --  Create a grid of plots to make the comparison easier to do
# -- hint: Task 9 -- We follow the same steps as we used in Task 6 to create
# the plots
# -- hint: Task 9 -- We follow similar steps as we used in Task 5 to:
# -- 1 -- name the plots  
# -- 2 -- create and show a grid of named plots

# -- First create the plots, giving them names:

# -- enter and run your code here --


# -- Second name the plots, to show them side-by-side in the plot window:

# -- enter and run your code here --


# -- Q.5. -- How does the association, shown in the plots, between mean.self
# and mean.acc compare when you look at the study.two versus the study.122 plot?
# -- hint: Q.5 -- When comparing evidence about associations in different
# studies, we are mostly going to focus on the slope -- the angle --
# of the prediction lines, and the ways in which points do or do not cluster
# about the prediction lines

# -- enter your answer here --


# -- We are now in a position to answer one of our research questions:
# 2. Can people accurately evaluate whether they correctly understand written 
# health information?

# -- If people *can* accurately evaluate whether they correctly understand written 
# # health information
# -- Then mean.self (a score representing their evaluation) should be associated
# with mean.acc (a score representing their accuracy of understanding)


# -- revision: make sure you are confident about doing these things --


# -- Task 10 --  Can you estimate the association between mean.acc
# and mean.self in both datasets?
# -- hint: Task 10 -- We use cor.test() as you have been shown how to do e.g. in:
# 2022-23-PSYC122-w16-how-to.R
# -- hint: Task 10 -- Do the correlation for both datasets: don't forget to change the dataset name:

# -- First, the correlation between mean.acc and mean.self in study.two

# -- enter and run your code here --


# -- Q.6. -- What is r, the correlation coefficient?

# -- enter your answer here --

# -- Q.7. -- Is the correlation significant?

# -- enter your answer here --

# -- Q.8. -- What are the values for t and p for the significance test for the correlation?

# -- enter your answer here --


# -- Second, the correlation between mean.acc and mean.self in study.122

# -- enter and run your code here --


# -- Q.9. -- What is r, the correlation coefficient?

# -- enter your answer here --

# -- Q.10. -- Is the correlation significant?

# -- enter your answer here --

# -- Q.11. -- What are the values for t and p for the significance test for the correlation?

# -- enter your answer here --


# -- Now we can answer the research question:
# 2. Can people accurately evaluate whether they correctly understand written 
# health information?


# -- Q.12. -- What do the correlation estimates tell you is the answer to the research question?

# -- enter your answer here --


# -- Q.13. --  Can you compare the estimates, given the two datasets, to evaluate if
# the result in study.two is replicated in study.122?
# # -- hint: Q.13. -- We can judge if the result in a study is replicated in another
# study by examining if -- here -- the correlation coefficient is significant in both
# studies *and* if the coefficient has the same size and sign in both studies

# -- enter your answer here --

 
# -- This may suggest that the association observed in study.two is different from
# the association in study.122, for some reason.


# -- Task 11 -- In working with R to do data analysis, we often work with libraries of function
# like {tidyverse} that enable us to do things (see the week 19 lecture for discussion).
# -- In this way, we are using the {patchwork} library so that we can create plots
# and then present them in a grid.
# -- Can you find the online information about {patchwork} and use it to adjust the layout of
# the grids of plots you are using?
# -- hint: Task 11 -- To find out more information about a function or a library in R, do a search
# for the keywords: in r ...
# e.g. paste the words inside the quotes "" into google: "in r patchwork"
# -- hint: Task 11 -- You will then see a list of results including the link to the {patchwork} 
# information:

# -- enter your answer here --



############################################################################################################
## Part 5: Use a linear model to to answer the research questions -- multiple predictors ###################


# -- revision: make sure you are confident about doing these things --


# -- Task 12 -- Examine the relation between outcome mean accuracy (mean.acc)
# and multiple predictors including:
# health literacy (HLVA); vocabulary (SHIPLEY); and reading strategy (FACTOR3)
# -- hint: Task 10 -- We use lm(), as before, see:
# 2022-23-PSYC122-w18-how-to.R


# -- Task 12 -- Examine the predictors of mean accuracy (mean.acc), first,
# for the study.two data

# -- enter and run your lm model code here --


# -- Using the model estimates, we can answer the research question:
# 1. What person attributes predict success in understanding?


# -- If you look at the model summary you can answer the following questions:  

# -- Q.18. -- What is the estimate for the coefficient of the effect of the predictor, 
# 'SHIPLEY', in *this* model?

# -- enter your answer here --

# -- Q.19. -- Is the effect significant?

# -- enter your answer here --

# -- Q.20. -- What are the values for t and p for the significance test for the coefficient?

# -- enter your answer here --

# -- Q.21. -- Now consider the estimates for all the variables, what do you 
# conclude is the answer to the research question -- given the study.two data:
# 1. What person attributes predict success in understanding?
# -- hint: Q.21. -- Can you report the model and the model fit statistics using the 
# language you have been shown in the week 18 lecture?

# -- enter your answer here --


# -- Task 13 -- Examine the predictors of mean accuracy (mean.acc), now,
# for the study.122 data

# -- enter and run your code here --


# -- Using the model estimates, we can answer the research question:
# 1. What person attributes predict success in understanding?


# -- If you look at the model summary you can answer the following questions:  

# -- Q.22. -- What is the estimate for the coefficient of the effect of the predictor, 
# 'HLVA', in *this* model?

# -- enter your answer here --

# -- Q.23. -- Is the effect significant?

# -- enter your answer here --

# -- Q.24. -- What are the values for t and p for the significance test for the coefficient?

# -- enter your answer here --

# -- Q.25. -- Now consider the estimates for all the variables, what do you 
# conclude is the answer to the research question -- given the study.122 data:
# 1. What person attributes predict success in understanding?
# -- hint: Q.25. -- Can you report the model and the model fit statistics using the 
# language you have been shown in the week 18 lecture?

# -- enter your answer here --


# -- At this point, we can evaluate the evidence from the PSYC122 sample -- based on your
# responses -- to assess if the patterns, the estimates, we saw previously are repeated
# in analyses of PSYC122 responses


# -- Q.26. -- Are the findings from study.two replicated in study.122?
# # -- hint: Q.26. -- We can judge if the results in an earlier study are replicated in another
# study by examining if -- here -- the linear model estimates are significant in both
# studies *and* if the coefficient estimates have the same size and sign in both studies

# -- enter your answer here --

  
# -- Q.27. -- How would you describe the outstanding difference between the results of 
# the two studies?
# -- hint: Q.27. -- We can look at the estimates but we can also use the model prediction
# plotting code you used before, see:
# 2022-23-PSYC122-w18-how-to.R
# 2022-23-PSYC122-w19-how-to.R
# -- hint: Q.27. -- Let's focus on comparing the study.two and study.122 estimates for
# the effect of HLVA in both models: we can plot model predictions, for comparison:

# -- First: fit the models -- using different names for the different models

# -- enter and run your code here --


# -- Second, create prediction plots for the HLVA effect for each model

# -- enter and run your code here --


# -- Third, show the plots side-by-side

# -- enter and run your code here --


# -- A.27. -- If we compare the estimates for the coefficient of the HLVA effect in
# the study.two and study.122 models we can see that:

# -- enter your answer here --


# -- Task 14 -- In producing prediction plots, we are using functions from the {ggefects} library.
# Can you locate online information about working with the library functions?
# -- hint: Task 14 -- Try doing a search with the key words: in r ggeffects 
# -- hint: Task 14 -- If you do that, you will see links to the website:
# https://strengejacke.github.io/ggeffects/

# -- Task 15 -- In the {ggeffects} online information, you can see links to practical examples.
# -- Can you use the information under "Practical examples" to adjust the appearance of the
# prediction plots: to make them black and white; to add points?

# -- Create the plots

# -- enter and run your code here --

# -- Show the plots

# -- enter and run your code here --


# -- Q.28. -- Given the information in the adjusted plots, can you explain why we appear
# to be more uncertain about the HLVA effect given the study.122 data?

# -- enter your answer here --
  


############################################################################################################

